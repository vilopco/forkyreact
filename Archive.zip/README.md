# Incrementa el número

Este repositorio ha sido creado con [Create React App](https://github.com/facebookincubator/create-react-app). Para resolver el reto debes realizar los siguientes pasos:

1. Haz un fork de este repo.
2. Clónalo en tu máquina.
3. Ejecuta `npm install`
4. Ejecuta `npm test` y revisa qué pruebas están fallando.
5. Resuelve el reto verificando que todas las pruebas pasen.
6. Haz commit y luego push a tu fork.
7. Ingresa tu fork en la plataforma de Make it Real.
